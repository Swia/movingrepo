#!/bin/sh
export LC_ALL=en_US.UTF-8
./alarms_bot.py
